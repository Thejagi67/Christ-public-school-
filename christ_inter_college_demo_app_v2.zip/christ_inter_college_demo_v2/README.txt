CHRIST INTER COLLEGE — DEMO APP V2
Files: index.html, style.css, app.js.

STUDENT DEMO LOGINS
CIC1001 / student123
CIC1002 / student123
CIC1003 / student123
CIC1004 / student123

ADMIN DEMO LOGIN
Username: admin
Password: admin123

Features: mobile-friendly home page, demo student login/dashboard, account switching, searchable sample directory, notices/holidays, admission enquiry form, demo admin notice publishing, enquiry review. Demo data is stored only in this browser.

To publish as a website: extract this ZIP and upload index.html, style.css, and app.js together to a static host such as GitHub Pages. Do not upload only the ZIP as the website source.

IMPORTANT: This is a front-end prototype, not a production school system. Demo credentials and student data are visible in app.js; the admin login is not secure. Forms do not send data to the school, email, or WhatsApp. Push notifications, cloud database, real authentication and official WhatsApp integration are not connected. Do not enter real student details or sensitive information. Real deployment requires a secure backend, server-side authentication, access controls, privacy safeguards, HTTPS, and school authorization.
